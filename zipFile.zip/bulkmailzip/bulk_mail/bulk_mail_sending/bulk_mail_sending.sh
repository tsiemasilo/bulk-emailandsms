#!/usr/bin/bash
cd /usr/src/app/bulk_mail_sending
python3 bulk_mail.py

